"""Parser-first controller. Packaged launchers ONLY request --validate-only."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
PS_NAME = "TMNM_MASTER338_UPLOAD_PREFLIGHT_GATE4_CLEAN_SUCCESSOR.ps1"
REAUTH = "TMNM_MASTER338_DRIVE_REAUTHORISE.py"
UPLOAD = "TMNM_MASTER338_DRIVE_UPLOAD.py"


def sanitise(value):
    text = re.sub(r"(?i)https?://[^\s<>]+", "[URL_REDACTED]", str(value))
    text = re.sub(r"(?i)\bBearer\s+\S+", "Bearer [REDACTED]", text)
    text = re.sub(r'''(?ix)(["']?(?:access_token|refresh_token|id_token|client_secret|authorization|code)["']?\s*[:=]\s*)(["'][^"']*["']|[^\s,;}]+)''', r"\1[REDACTED]", text)
    text = re.sub(r"\b(?:ya29\.|1//|GOCSPX-)[A-Za-z0-9_.~+/=-]+", "[REDACTED]", text)
    return text[-12000:]


def run(argv, env=None, timeout=180):
    return subprocess.run(argv, env=env, capture_output=True, text=True,
                          errors="replace", timeout=timeout, check=False)


def powershell(code, env=None):
    return run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", code], env)


def parser_gate(root, log):
    code = r'''
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -ne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5) { throw 'WINDOWS_POWERSHELL_5_REQUIRED' }
$files = @(Get-ChildItem -LiteralPath $env:TMNM_PARSE_ROOT -Filter '*.ps1' -File)
if ($files.Count -eq 0) { throw 'NO_POWERSHELL_FILES' }
foreach ($file in $files) {
  $tokens = $null; $errors = $null
  $null = [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
  if ($errors.Count -gt 0) {
    foreach ($e in $errors) { Write-Output ($file.Name + ':' + $e.Extent.StartLineNumber + ':' + $e.ErrorId) }
    exit 1
  }
}
Write-Output ('ENGINE=' + $PSVersionTable.PSVersion.ToString())
Write-Output 'PARSER_PREFLIGHT=PASS'
'''
    p = powershell(code, dict(os.environ, TMNM_PARSE_ROOT=str(root)))
    log.append(sanitise(p.stdout + p.stderr))
    if p.returncode or "PARSER_PREFLIGHT=PASS" not in p.stdout:
        raise RuntimeError("WINDOWS_POWERSHELL_PARSER_GATE_FAILED")


def verify_manifest(root):
    entries = {}
    for line in (root / "SHA256_MANIFEST.txt").read_text().splitlines():
        digest, name = line.split(None, 1)
        if Path(name).name != name or name in entries:
            raise RuntimeError("INVALID_MANIFEST_ENTRY")
        entries[name] = digest.upper()
    actual = {p.name for p in root.iterdir() if p.is_file() and p.name != "SHA256_MANIFEST.txt"}
    if actual != set(entries):
        raise RuntimeError("MANIFEST_FILE_SET_MISMATCH")
    for name, expected in entries.items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest().upper() != expected:
            raise RuntimeError("MANIFEST_HASH_MISMATCH:" + name)


def restore_token(token, backup, expected, log):
    if not backup.is_file() or backup.read_bytes() != expected:
        raise RuntimeError("ROLLBACK_BACKUP_INVALID_PRESERVED")
    with token.open("wb") as f:
        f.write(expected)
        f.flush()
        os.fsync(f.fileno())
    if token.read_bytes() != expected:
        raise RuntimeError("ROLLBACK_READBACK_FAILED_BACKUP_PRESERVED")
    backup.unlink()
    log.append("TOKEN_ROLLBACK=VERIFIED")


def transaction(local, operation, log):
    token = local / "google_token.dpapi"
    backup = local / "google_token.dpapi.reauth_backup"
    new = local / "google_token.dpapi.new"
    if backup.exists() or new.exists():
        raise RuntimeError("STALE_CREDENTIAL_ARTIFACT_REQUIRES_REVIEW")
    original = token.read_bytes()
    if not original:
        raise RuntimeError("EMPTY_ORIGINAL_TOKEN")
    try:
        with backup.open("xb") as f:
            f.write(original)
            f.flush()
            os.fsync(f.fileno())
        if backup.read_bytes() != original:
            raise RuntimeError("BACKUP_READBACK_FAILED")
    except BaseException:
        if token.read_bytes() == original and backup.exists():
            backup.unlink()
        raise
    committed = False
    try:
        rc = operation()
        if rc:
            return rc
        if not token.is_file() or not token.read_bytes():
            raise RuntimeError("REPLACEMENT_TOKEN_MISSING")
        backup.unlink()
        committed = True
        log.append("TOKEN_COMMIT=PASS")
        return 0
    finally:
        if not committed:
            restore_token(token, backup, original, log)
        if new.exists():
            new.unlink()


def desktop_path():
    p = powershell("[Environment]::GetFolderPath('Desktop')")
    value = p.stdout.strip()
    if p.returncode or not value or not Path(value).is_dir():
        raise RuntimeError("DESKTOP_RESOLUTION_FAILED")
    return Path(value)


def clipboard(path):
    p = powershell(r'''
$ErrorActionPreference = 'Stop'
$text = [IO.File]::ReadAllText($env:TMNM_FINAL_RESULT)
Set-Clipboard -Value $text
if ((Get-Clipboard -Raw) -cne $text) { throw 'CLIPBOARD_READBACK_MISMATCH' }
Write-Output 'CLIPBOARD=VERIFIED'
''', dict(os.environ, TMNM_FINAL_RESULT=str(path)))
    return p.returncode == 0 and "CLIPBOARD=VERIFIED" in p.stdout


def main(argv=None):
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--validate-only", action="store_true")
    mode.add_argument("--execute", action="store_true")
    opts = parser.parse_args(argv)
    run_id = uuid.uuid4().hex
    log = ["TMNM MASTER342", "RUN_ID=" + run_id,
           "UTC=" + datetime.now(timezone.utc).isoformat(),
           "MODE=" + ("NONLIVE" if opts.execute else "PARSER_ONLY"),
           "PUBLISH=HOLD", "FACEBOOK=PROHIBITED"]
    rc, result, work, upload_allowed = 1, None, None, False
    try:
        if os.name != "nt":
            raise RuntimeError("WINDOWS_REQUIRED")
        result = desktop_path() / ("TMNM_MASTER342_RESULT_" + run_id + ".txt")
        result.write_text("\n".join(log + ["STATUS=STARTED"]), encoding="utf-8")
        verify_manifest(ROOT)
        parser_gate(ROOT, log)
        if not opts.execute:
            log.append("OPERATIONAL_EXECUTION=NOT_PERFORMED")
            rc = 0
        else:
            local = Path(os.environ["LOCALAPPDATA"]) / "TMNM" / "LocalWorker"
            for required in (local / "client_secret.json", ROOT / REAUTH, ROOT / UPLOAD, ROOT / PS_NAME):
                if not required.is_file():
                    raise RuntimeError("MISSING_REQUIRED_FILE:" + required.name)
            work = Path(tempfile.mkdtemp(prefix="TMNM_MASTER342_"))
            stage_result = work / "successor_result.txt"
            env = dict(os.environ, TMNM_REAUTH_CONTROLLER="MASTER342", TMNM_RESULT_PATH=str(stage_result))

            def operation():
                nonlocal upload_allowed
                p = run([sys.executable, str(ROOT / REAUTH)], env, timeout=600)
                # OAuth output may contain secrets; retain only the stage and return code.
                log.append("REAUTH_EXIT=" + str(p.returncode))
                if p.returncode:
                    return p.returncode
                upload_allowed = True
                p = run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / PS_NAME)], env, timeout=600)
                log.append("SUCCESSOR_EXIT=" + str(p.returncode))
                log.append(sanitise(p.stdout + p.stderr))
                if stage_result.exists():
                    text = stage_result.read_text(encoding="utf-8-sig")
                    log.append(sanitise(text))
                    if p.returncode == 0 and not re.search(r"(?m)^STATUS=PASS\s*$", text):
                        return 1
                else:
                    log.append("SUCCESSOR_RESULT=MISSING")
                    return 1
                return p.returncode

            rc = transaction(local, operation, log)
    except BaseException as exc:
        log.append("CONTROLLER_ERROR=" + sanitise(type(exc).__name__ + ":" + str(exc)))
        rc = 1
    finally:
        if work is not None:
            try:
                shutil.rmtree(work)
                log.append("LOCAL_TEMP_CLEANUP=PASS")
            except OSError as exc:
                log.append("LOCAL_TEMP_CLEANUP=FAIL:" + sanitise(exc))
                rc = 1
        log.append("CONTROLLER_STATUS=" + ("PASS" if rc == 0 else "FAIL"))
        log.append("EXIT_CODE=" + str(rc))
        text = "\n".join(log) + "\n"
        try:
            if result is None:
                result = Path(tempfile.gettempdir()) / ("TMNM_MASTER342_RESULT_" + run_id + ".txt")
            result.write_text(text, encoding="utf-8")
            if upload_allowed and os.name == "nt":
                try:
                    p = run([sys.executable, str(ROOT / UPLOAD), "result", str(result)])
                    good = p.returncode == 0 and p.stdout.startswith("PASS ID=")
                    text += "DRIVE_UPLOAD=" + ("VERIFIED" if good else "FAIL") + "\n" + sanitise(p.stdout + p.stderr) + "\n"
                    if not good:
                        rc = 1
                except BaseException as exc:
                    text += "DRIVE_UPLOAD=FAIL:" + sanitise(exc) + "\n"
                    rc = 1
                result.write_text(text, encoding="utf-8")
            text += 'FINAL_EXIT_CODE=' + str(rc) + '\n'
            result.write_text(text, encoding="utf-8")
            print(text, flush=True)
            print("RESULT=" + str(result), flush=True)
            try:
                copied = clipboard(result)
            except BaseException:
                copied = False
            print("CLIPBOARD=" + ("VERIFIED" if copied else "FAILED; RESULT DISPLAYED ABOVE"), flush=True)
            if not copied:
                rc = 1
            marker = os.environ.get("TMNM_COMPLETION_MARKER")
            if marker:
                Path(marker).write_text(str(result), encoding="utf-8")
        except BaseException as exc:
            print(text, flush=True)
            print("RESULT_OUTPUT_FAILED=" + sanitise(exc), flush=True)
            rc = 1
    return rc


if __name__ == "__main__":
    sys.exit(main())
