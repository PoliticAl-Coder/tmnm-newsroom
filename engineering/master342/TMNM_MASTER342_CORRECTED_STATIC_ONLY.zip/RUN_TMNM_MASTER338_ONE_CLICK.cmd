@echo off
setlocal EnableExtensions DisableDelayedExpansion
title TMNM MASTER342 - STATIC VALIDATION ONLY
set "PY=%LOCALAPPDATA%\TMNM\LocalWorker\.venv\Scripts\python.exe"
set "TMNM_COMPLETION_MARKER=%TEMP%\TMNM_MASTER342_%RANDOM%_%RANDOM%_%RANDOM%.done"
if exist "%TMNM_COMPLETION_MARKER%" goto markerconflict
if not exist "%PY%" goto missingpython
"%PY%" "%~dp0TMNM_MASTER342_CONTROLLER.py" --validate-only
set "RC=%ERRORLEVEL%"
if not exist "%TMNM_COMPLETION_MARKER%" goto controllerfailed
del /q "%TMNM_COMPLETION_MARKER%"
goto terminal
:missingpython
set "RC=1"
set "TMNM_BOOT_ERROR=STATUS=FAIL - LocalWorker Python missing. No operations started."
goto fallback
:controllerfailed
set "RC=1"
set "TMNM_BOOT_ERROR=STATUS=FAIL - Controller did not complete reporting. Preserve visible error above."
goto fallback
:markerconflict
set "RC=1"
set "TMNM_BOOT_ERROR=STATUS=FAIL - Completion marker collision. No operations started."
:fallback
echo %TMNM_BOOT_ERROR%
powershell.exe -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; Set-Clipboard -Value $env:TMNM_BOOT_ERROR; if ((Get-Clipboard -Raw) -cne $env:TMNM_BOOT_ERROR) { exit 1 }; Write-Output 'CLIPBOARD=VERIFIED'"
if errorlevel 1 echo CLIPBOARD=FAILED - result remains visible above.
:terminal
echo Controller exit code: %RC%
echo STATIC PACKAGE ONLY. OPERATIONAL EXECUTION IS NOT AUTHORISED.
echo Window will remain open for inspection.
pause
exit /b %RC%
