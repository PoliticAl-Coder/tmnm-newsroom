$ErrorActionPreference='Stop'
$ExpectedAuthSha='CD09099EC23622A7AD27CBD495EAC3D0CD7C9371330BD04981B97429973B6C9E'
$ExpectedPackage='TMNM-20260911-FB-OWNER-PROOF-01'
$ExpectedDestination='TMNM'
$ManifestId='1k8XM4NeOiuR3s6Bq_AlYM73dD4-WhZ93'
$ArticleId='1O73NLNL41qHB3hNqy6Ivw8kOVXwyjTWA-ghTKf1q7qE'
$ExpectedImageId='1lZnk6-Qg6fePUWDfRoHxUuiiQhvSYE1b'
$ExpectedImageSha='5FD5A1350B72E16E70A10587CE8282FEFE4A66612FDDDB392EFCFF46EE31CB8E'
$EmDash=[char]0x2014
$ExpectedHeadline='TMNM FACEBOOK OWNER-PROOF TEST '+$EmDash+' NO NEWS CONTENT'
$ExpectedArticle=$ExpectedHeadline+"`r`nTechnical publishing-path verification only.`r`nPackage: TMNM-20260911-FB-OWNER-PROOF-01`r`nThis temporary test post may be deleted after verification."

$Local=Join-Path $env:LOCALAPPDATA 'TMNM\LocalWorker'
$Py=Join-Path $Local '.venv\Scripts\python.exe'
$Auth=Join-Path $Local 'app\google_auth.py'
$Bridge=Join-Path $Local 'app\live_drive_bridge_json_shim.py'
$Cfg=Join-Path $Local 'config.live.json'
$Tmp=Join-Path ([IO.Path]::GetTempPath()) ('TMNM_MASTER338_'+[guid]::NewGuid().ToString('N'))
$Result=New-Object System.Collections.Generic.List[string]
$Stage='INIT'
function Put($k,$v){$Result.Add("$k=$v")}
function Stage([string]$v){$script:Stage=$v; Put 'STAGE' $v}
function Run-Python([string[]]$Arguments,[string]$Out,[string]$Err){
  $Quoted = foreach ($Arg in $Arguments) {
    '"' + (($Arg -replace '(\\*)"', '$1$1\"') -replace '(\\+)$', '$1$1') + '"'
  }
  Start-Process -FilePath $Py -ArgumentList $Quoted -Wait -PassThru -NoNewWindow -RedirectStandardOutput $Out -RedirectStandardError $Err
}
function Finish([int]$Code){
  Put 'FINAL_STAGE' $Stage; Put 'PUBLISH_CALLS' '0'; Put 'PROVIDER_CALLS' '0'; Put 'FACEBOOK_CALLS' '0'
  $Text=$Result -join "`r`n"
  try {
    if ([string]::IsNullOrWhiteSpace($env:TMNM_RESULT_PATH)) { throw 'CONTROLLER_RESULT_PATH_REQUIRED' }
    # Result is unique to this run. Controller sanitises, uploads and presents it
    # only after credential commit/rollback. No nested clipboard or pause.
    foreach ($File in @(Get-ChildItem -LiteralPath $Tmp -Filter '*.err' -ErrorAction SilentlyContinue)) {
      $Diagnostic = Get-Content -LiteralPath $File.FullName -Raw
      if ($Diagnostic) {
        # Preserve error class/status only, not arbitrary credential-bearing output.
        $Kinds = [regex]::Matches($Diagnostic, '(?m)\b[A-Za-z_][A-Za-z0-9_]*(?:Error|Exception)\b|\b(?:invalid_grant|insufficientPermissions|access_denied)\b|\bHttpError\s+\d{3}\b')
        foreach ($Kind in $Kinds) { $Text += "`r`nDIAGNOSTIC=" + $File.Name + ':' + $Kind.Value }
      }
    }
    [IO.File]::WriteAllText($env:TMNM_RESULT_PATH,$Text,[Text.UTF8Encoding]::new($false))
  } finally {
    if (Test-Path -LiteralPath $Tmp) { Remove-Item -LiteralPath $Tmp -Recurse -Force -ErrorAction Stop }
  }
  exit $Code
}
try {
  if ($env:TMNM_REAUTH_CONTROLLER -ne 'MASTER342') { throw 'CONTROLLER_REQUIRED' }
  New-Item -ItemType Directory -Path $Tmp | Out-Null
  Stage 'REQUIRED_FILES'
  $Uploader=Join-Path $PSScriptRoot 'TMNM_MASTER338_DRIVE_UPLOAD.py'
  foreach($F in @($Py,$Auth,$Bridge,$Cfg,$Uploader)){if(-not(Test-Path $F -PathType Leaf)){throw "MISSING_REQUIRED_FILE=$F"}}

  Stage 'DRIVE_WRITE_PREFLIGHT'
  $Probe=Join-Path $Tmp 'drive_preflight.txt'
  $ProbeText='TMNM_MASTER338_DRIVE_WRITE_PREFLIGHT '+[guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($Probe,$ProbeText,[Text.UTF8Encoding]::new($false))
  $POut=Join-Path $Tmp 'preflight.out'; $PErr=Join-Path $Tmp 'preflight.err'
  $PP=Run-Python @($Uploader,'preflight',$Probe) $POut $PErr
  if($PP.ExitCode -ne 0){throw "DRIVE_WRITE_PREFLIGHT_RC=$($PP.ExitCode)"}
  $Receipt=(Get-Content $POut -Raw).Trim()
  if($Receipt -notmatch '^PASS ID='){throw 'DRIVE_WRITE_PREFLIGHT_NO_VERIFIED_RECEIPT'}
  Put 'DRIVE_WRITE_PREFLIGHT' $Receipt

  Stage 'AUTH_SOURCE_HASH'
  $AuthSha=(Get-FileHash $Auth -Algorithm SHA256).Hash.ToUpperInvariant()
  if($AuthSha -ne $ExpectedAuthSha){throw "AUTH_SOURCE_HASH_MISMATCH=$AuthSha"}
  Put 'GOOGLE_AUTH_SHA256' $AuthSha

  Stage 'PORT8766_LISTENER'
  $Listeners=@(Get-NetTCPConnection -LocalPort 8766 -State Listen -ErrorAction Stop)
  if($Listeners.Count -ne 1){throw "PORT8766_LISTENER_COUNT=$($Listeners.Count)"}
  $Pid8766=$Listeners[0].OwningProcess
  $Proc=Get-CimInstance Win32_Process -Filter "ProcessId=$Pid8766"
  if(-not $Proc){throw 'PORT8766_PROCESS_NOT_FOUND'}
  $Cmd=[string]$Proc.CommandLine
  if([string]::IsNullOrWhiteSpace($Cmd)){throw 'PORT8766_COMMANDLINE_EMPTY'}

  Stage 'PORT8766_SOURCE_RESOLUTION'
  $Candidates=New-Object System.Collections.Generic.List[string]
  $Matches=[regex]::Matches($Cmd,'(?i)([A-Z]:\\[^"]*?\\tmnm_owner_console\\app(?:\.py)?)')
  foreach($M in $Matches){$Candidates.Add($M.Groups[1].Value)}
  if($Candidates.Count -ne 1){throw "PORT8766_SOURCE_PATH_COUNT=$($Candidates.Count)"}
  $LiveApp=$Candidates[0]
  $LiveRoot=Split-Path $LiveApp -Parent
  $Workflow=Join-Path $LiveRoot 'owner_workflow.py'
  if(-not(Test-Path $Workflow -PathType Leaf)){throw "OWNER_WORKFLOW_NOT_FOUND=$Workflow"}
  Put 'PORT8766_PID' $Pid8766
  Put 'OWNER_WORKFLOW_PATH' $Workflow
  Put 'OWNER_WORKFLOW_SHA256' ((Get-FileHash $Workflow -Algorithm SHA256).Hash.ToUpperInvariant())

  Stage 'DIRECT_MANIFEST'
  $MOut=Join-Path $Tmp 'manifest.json'; $MErr=Join-Path $Tmp 'manifest.err'
  $P=Run-Python @($Bridge,'read-json','--config',$Cfg,'--file-id',$ManifestId) $MOut $MErr
  if($P.ExitCode -ne 0){throw "READ_JSON_RC=$($P.ExitCode)"}
  $MJ=(Get-Content $MOut -Raw | ConvertFrom-Json).value
  if($MJ.package_id -ne $ExpectedPackage){throw 'PACKAGE_ID_MISMATCH'}
  if($MJ.destination -ne $ExpectedDestination){throw 'DESTINATION_MISMATCH'}
  if($MJ.headline -ne $ExpectedHeadline){throw 'HEADLINE_MISMATCH'}
  if($MJ.article_doc_id -ne $ArticleId){throw 'ARTICLE_ID_MISMATCH'}
  if($MJ.image_file_id -ne $ExpectedImageId){throw 'IMAGE_ID_MISMATCH'}
  if(([string]$MJ.image_sha256).ToUpperInvariant() -ne $ExpectedImageSha){throw 'IMAGE_SHA_MISMATCH'}
  Put 'DIRECT_MANIFEST' 'PASS'

  Stage 'DIRECT_ARTICLE'
  $AOut=Join-Path $Tmp 'article.json'; $AErr=Join-Path $Tmp 'article.err'
  $P=Run-Python @($Bridge,'export-doc','--config',$Cfg,'--file-id',$ArticleId) $AOut $AErr
  if($P.ExitCode -ne 0){throw "EXPORT_DOC_RC=$($P.ExitCode)"}
  $Article=(Get-Content $AOut -Raw | ConvertFrom-Json).text
  $Norm=($Article -replace "`r?`n","`r`n").Trim()
  if($Norm -ne $ExpectedArticle){throw 'ARTICLE_CONTENT_MISMATCH'}
  Put 'DIRECT_ARTICLE' 'PASS'

  Stage 'NONLIVE_ACTIONABILITY'
  $Facts=[ordered]@{
    package_id=$ExpectedPackage
    destination=$ExpectedDestination
    workflow_status='READY_FOR_REVIEW'
    title=$ExpectedHeadline
    author='TMNM'
    article_text=$Norm
    article_doc_id=$ArticleId
    image=@{source_drive_id=$ExpectedImageId;source_sha256=$ExpectedImageSha}
    review_ready=$true
  }
  $FactsPath=Join-Path $Tmp 'facts.json'
  $Facts | ConvertTo-Json -Depth 6 | Set-Content $FactsPath -Encoding UTF8

  $Harness=Join-Path $Tmp 'gate.py'
  $PyText=@'
import os,sys,json,tempfile,shutil,socket,urllib.request,importlib.util
wf,facts_path=sys.argv[1:3]
def blocked(*a,**k): raise RuntimeError("NETWORK_BLOCKED")
socket.create_connection=blocked
socket.socket.connect=blocked
urllib.request.urlopen=blocked
spec=importlib.util.spec_from_file_location("wf_nonlive",wf)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
with open(facts_path,encoding="utf-8-sig") as f:
    p=json.load(f)
snap=m.canonical_snapshot(p)
ok,reason=m.validate_actionable(snap)
print("VALIDATE_ACTIONABLE="+str(ok).upper())
if not ok:
    print("REASON="+str(reason))
    raise SystemExit(41)
tmp=tempfile.mkdtemp(prefix="tmnm_shadow_")
try:
    db=os.path.join(tmp,"shadow.sqlite")
    store=m.WorkflowStore(db)
    payload,payload_sha=store.payload_for(p)
    print("PAYLOAD_FOR=PASS")
    print("PAYLOAD_SHA256="+payload_sha)
    print("DURABLE_AUTHORITY_CLAIM=NOT_CALLED")
    print("PROVIDER_CALLS=0")
    print("FACEBOOK_CALLS=0")
finally:
    close = getattr(store, "close", None) if "store" in locals() else None
    if callable(close):
        close()
    shutil.rmtree(tmp)
'@
  [IO.File]::WriteAllText($Harness,$PyText,[Text.UTF8Encoding]::new($false))
  $GOut=Join-Path $Tmp 'gate.out'
  $GErr=Join-Path $Tmp 'gate.err'
  $P=Run-Python @($Harness,$Workflow,$FactsPath) $GOut $GErr
  $GT=Get-Content $GOut -Raw
  if($P.ExitCode -ne 0 -or $GT -notmatch 'VALIDATE_ACTIONABLE=TRUE' -or $GT -notmatch 'PAYLOAD_FOR=PASS'){throw "NONLIVE_GATE_FAIL_RC=$($P.ExitCode)"}
  Put 'NONLIVE_ACTIONABILITY' 'PASS'
  Put 'SHADOW_STORE' 'TEMPORARY_REMOVED'
  Put 'DURABLE_AUTHORITY_CLAIM' 'NOT_CALLED'
  Put 'STATUS' 'PASS'
  Finish 0
}catch{
  Put 'STATUS' 'FAIL'; Put 'ERROR' ($_.Exception.Message); Finish 1
}
