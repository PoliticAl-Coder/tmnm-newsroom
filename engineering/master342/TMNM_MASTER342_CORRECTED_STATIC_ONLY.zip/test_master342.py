"""Offline tests: synthetic token bytes only; no OAuth, Drive, Windows or live checks."""
import ast
from pathlib import Path
import re
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import TMNM_MASTER342_CONTROLLER as c


class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.local = Path(self.tmp.name)
        self.token = self.local / 'google_token.dpapi'
        self.backup = self.local / 'google_token.dpapi.reauth_backup'
        self.token.write_bytes(b'SYNTHETIC_ORIGINAL')
        self.log = []

    def tearDown(self):
        self.tmp.cleanup()

    def check_restored(self):
        self.assertEqual(self.token.read_bytes(), b'SYNTHETIC_ORIGINAL')
        self.assertFalse(self.backup.exists())
        self.assertIn('TOKEN_ROLLBACK=VERIFIED', self.log)

    def test_success_commits_then_cleans(self):
        def operation():
            self.assertEqual(self.backup.read_bytes(), b'SYNTHETIC_ORIGINAL')
            self.token.write_bytes(b'SYNTHETIC_REPLACEMENT')
            return 0
        self.assertEqual(c.transaction(self.local, operation, self.log), 0)
        self.assertFalse(self.backup.exists())
        self.assertEqual(self.token.read_bytes(), b'SYNTHETIC_REPLACEMENT')

    def test_nonzero_restores_before_return(self):
        def operation():
            self.token.write_bytes(b'SYNTHETIC_REPLACEMENT')
            return 7
        self.assertEqual(c.transaction(self.local, operation, self.log), 7)
        self.check_restored()

    def test_exception_restores(self):
        def operation():
            self.token.write_bytes(b'SYNTHETIC_REPLACEMENT')
            raise RuntimeError('injected')
        with self.assertRaisesRegex(RuntimeError, 'injected'):
            c.transaction(self.local, operation, self.log)
        self.check_restored()

    def test_interrupt_restores(self):
        def operation():
            self.token.write_bytes(b'SYNTHETIC_REPLACEMENT')
            raise KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            c.transaction(self.local, operation, self.log)
        self.check_restored()

    def test_stale_backup_is_not_deleted(self):
        self.backup.write_bytes(b'KEEP_RECOVERY_COPY')
        with self.assertRaisesRegex(RuntimeError, 'STALE_CREDENTIAL'):
            c.transaction(self.local, lambda: self.fail('operation started'), self.log)
        self.assertEqual(self.backup.read_bytes(), b'KEEP_RECOVERY_COPY')

    def test_restore_failure_preserves_backup(self):
        def operation():
            self.token.unlink()
            self.token.mkdir()  # Inject an unwritable restoration target.
            return 1
        with self.assertRaises(OSError):
            c.transaction(self.local, operation, self.log)
        self.assertEqual(self.backup.read_bytes(), b'SYNTHETIC_ORIGINAL')

    def test_missing_replacement_rolls_back(self):
        def operation():
            self.token.unlink()
            return 0
        with self.assertRaisesRegex(RuntimeError, 'REPLACEMENT_TOKEN_MISSING'):
            c.transaction(self.local, operation, self.log)
        self.check_restored()


class StaticAndGateTests(unittest.TestCase):
    def test_python_sources_parse(self):
        for file in c.ROOT.glob('*.py'):
            ast.parse(file.read_text(), filename=file.name)

    def test_embedded_python_parses(self):
        ps = (c.ROOT / c.PS_NAME).read_text()
        harness = ps.split("$PyText=@'", 1)[1].split("'@", 1)[0]
        ast.parse(harness)

    def test_parser_missing_fails_closed(self):
        with patch.object(c, 'powershell', side_effect=FileNotFoundError):
            with self.assertRaises(FileNotFoundError):
                c.parser_gate(c.ROOT, [])

    def test_parser_error_fails_closed(self):
        with patch.object(c, 'powershell', return_value=SimpleNamespace(returncode=1, stdout='syntax', stderr='')):
            with self.assertRaisesRegex(RuntimeError, 'PARSER_GATE_FAILED'):
                c.parser_gate(c.ROOT, [])

    def test_exit_zero_without_pass_is_rejected(self):
        with patch.object(c, 'powershell', return_value=SimpleNamespace(returncode=0, stdout='', stderr='')):
            with self.assertRaises(RuntimeError):
                c.parser_gate(c.ROOT, [])

    def test_mock_parser_pass_contract_only(self):
        with patch.object(c, 'powershell', return_value=SimpleNamespace(returncode=0, stdout='PARSER_PREFLIGHT=PASS', stderr='')):
            c.parser_gate(c.ROOT, [])

    def test_redaction(self):
        text = c.sanitise('access_token="SECRET" refresh_token=SECRET Bearer SECRET https://x/?code=SECRET ya29.SECRET')
        self.assertNotIn('SECRET', text)

    def test_single_pause_static_launcher(self):
        cmds = list(c.ROOT.glob('*.cmd'))
        self.assertEqual(sum(len(re.findall(r'(?im)^pause\s*$', f.read_text())) for f in cmds), 1)
        self.assertTrue(all('--execute' not in f.read_text() for f in cmds))
        self.assertIn('--validate-only', (c.ROOT / 'RUN_TMNM_MASTER338_ONE_CLICK.cmd').read_text())

    def test_core_gate_retained(self):
        ps = (c.ROOT / c.PS_NAME).read_text()
        for required in ('m.canonical_snapshot(p)', 'm.validate_actionable(snap)', 'm.WorkflowStore(db)', 'store.payload_for(p)', 'socket.create_connection=blocked', 'socket.socket.connect=blocked', 'urllib.request.urlopen=blocked'):
            self.assertIn(required, ps)
        self.assertNotIn('WorkflowStore()', ps)
        self.assertNotIn('Set-Clipboard', ps)
        self.assertNotIn('ignore_errors=True', ps)

    def test_manifest(self):
        c.verify_manifest(c.ROOT)


if __name__ == '__main__':
    unittest.main(verbosity=2)
