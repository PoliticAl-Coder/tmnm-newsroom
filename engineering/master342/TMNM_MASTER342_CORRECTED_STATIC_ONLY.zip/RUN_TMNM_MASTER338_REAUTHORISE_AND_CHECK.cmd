@echo off
rem Compatibility entry point; only the outer one-click wrapper pauses.
call "%~dp0RUN_TMNM_MASTER338_ONE_CLICK.cmd"
exit /b %ERRORLEVEL%
