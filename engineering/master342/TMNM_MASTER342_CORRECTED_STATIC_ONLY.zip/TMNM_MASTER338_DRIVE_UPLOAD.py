import sys, json, ctypes, ctypes.wintypes as wt, pathlib, datetime, hashlib, io, os
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

FOLDER_ID = "1Hdm7dEcRLA-OHJWfmEZulwZ8M4w5GwI7"
TOKEN = pathlib.Path(os.environ["LOCALAPPDATA"]) / "TMNM" / "LocalWorker" / "google_token.dpapi"

class DATA_BLOB(ctypes.Structure):
    _fields_=[("cbData",wt.DWORD),("pbData",ctypes.POINTER(ctypes.c_byte))]

def unprotect(data: bytes)->bytes:
    src=(ctypes.c_byte*len(data)).from_buffer_copy(data)
    ib=DATA_BLOB(len(data),src); ob=DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(ib),None,None,None,None,0,ctypes.byref(ob)):
        raise ctypes.WinError()
    try: return ctypes.string_at(ob.pbData,ob.cbData)
    finally: ctypes.windll.kernel32.LocalFree(ob.pbData)

def service():
    info=json.loads(unprotect(TOKEN.read_bytes()).decode("utf-8-sig"))
    return build("drive","v3",credentials=Credentials.from_authorized_user_info(info),cache_discovery=False)

def upload_and_verify(svc, path, name, delete_after_verify=False):
    local=path.read_bytes()
    local_sha=hashlib.sha256(local).hexdigest().upper()
    media=MediaFileUpload(str(path),mimetype="text/plain",resumable=False)
    r=svc.files().create(body={"name":name,"parents":[FOLDER_ID]},media_body=media,fields="id,name,size").execute()
    fid=r["id"]
    try:
        buf=io.BytesIO()
        dl=MediaIoBaseDownload(buf,svc.files().get_media(fileId=fid))
        done=False
        while not done:
            _,done=dl.next_chunk()
        remote=buf.getvalue()
        remote_sha=hashlib.sha256(remote).hexdigest().upper()
        if remote != local or remote_sha != local_sha:
            raise RuntimeError("DRIVE_READBACK_BYTE_MISMATCH")
    finally:
        if delete_after_verify:
            # Applies to download errors as well as mismatches. Fail closed if
            # cleanup fails and retain the precise orphan ID for later cleanup.
            try:
                svc.files().delete(fileId=fid).execute()
            except Exception as exc:
                raise RuntimeError("PREFLIGHT_CLEANUP_FAILED_ID="+fid) from exc
    return fid,local_sha,len(local)

def main():
    mode=sys.argv[1]
    svc=service()
    if mode=="preflight":
        p=pathlib.Path(sys.argv[2])
        fid,sha,size=upload_and_verify(svc,p,"TMNM_MASTER342_UPLOAD_PREFLIGHT.txt",delete_after_verify=True)
        print(f"PASS ID={fid} SHA256={sha} SIZE={size}")
        return
    if mode=="result":
        p=pathlib.Path(sys.argv[2])
        stamp=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        fid,sha,size=upload_and_verify(svc,p,f"TMNM_MASTER342_RESULT_{stamp}.txt")
        print(f"PASS ID={fid} SHA256={sha} SIZE={size}")
        return
    raise SystemExit("BAD_MODE")

if __name__=="__main__": main()
