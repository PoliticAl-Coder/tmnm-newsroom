TMNM MASTER342 - CORRECTED SOURCE / ENGINEERING VALIDATION ONLY

EXECUTION=NOT AUTHORISED
PUBLISH=HOLD
FACEBOOK=PROHIBITED
ALAN=NO ACTION

Source: MASTER338 ZIP SHA256
42D693CC9F20687DDAF94CB84784B3B06F746D056E3684D4B06BC33B2DCAED89
Existing MASTER338 component filenames are retained for compatibility.
The package and reporting revision is MASTER342.

CHANGES
One Python controller owns parser gating, credentials, results and cleanup.
The genuine Windows PowerShell 5 parser is called before OAuth/token changes.
Both packaged CMDs route ONLY to --validate-only; no OAuth or Drive calls.
One CMD pause occurs after controller termination; no inner pause.
Credential rollback verifies exact restored bytes before removing its backup.
Success commits/removes the backup before reporting. Failed restoration
preserves the only recovery copy and reports failure, not a cleanup PASS.
Pre-existing credential backup/new files stop the run without deleting them.
Fresh UUID-named results use the actual Windows Desktop known-folder path.
Early Desktop failure uses an explicitly reported, fresh temporary result.
Clipboard contents are read back and compared; failures remain visible.
Bootstrap failures have a visible fallback; an unavailable clipboard cannot
be guaranteed, and is reported as failed instead of claiming success.
Sanitised diagnostics are retained before working-directory cleanup.
OAuth stdout/stderr are deliberately not retained; stage/exit code are retained.
Direct Drive hydration and isolated WorkflowStore(shadow.sqlite) remain.
Drive preflight cleanup now also covers download/readback exceptions.
Subprocess file arguments are quoted for paths containing spaces.
No local live workflow source or service was modified or invoked.

VALIDATION BOUNDARY
Offline Python tests use synthetic tokens, temporary directories and mocked
PowerShell responses. They are NOT a genuine PowerShell parser PASS.
Windows PowerShell, CMD, clipboard, DPAPI and OAuth are unavailable here.
An engineering Windows machine must validate parser-only operation, terminal
paths, space-containing paths, clipboard readback and synthetic rollback.
Only then may a reviewed operational release be authorised.
The controller's --execute branch exists for subsequent review; neither
packaged CMD invokes it. Do not modify a launcher and ask Alan to test it.

LIMITS AND PRESERVATION
Abrupt process termination, OS shutdown and hardware failure cannot guarantee
Python finally blocks or clipboard operations. Stale backups are preserved
and fail closed on a subsequent attempt. No credential copies enter results.
On an authorised failed operation, token restoration precedes final upload;
the restored read-only token may not upload the result. In that case the
fresh visible local/clipboard result remains the fallback, with upload failure.
Verified Drive evidence contains the transaction outcome; its own upload
receipt is appended locally afterwards and is not a recursive self-upload.
The runtime workflow is dynamically imported as before; these existing
network monkey patches are not an OS-level security sandbox. Runtime source
inspection/isolation review is still required before operational approval.
Canonical input ZIP and final evidence are preserved. Temporary test data
are removed. Recovery backups are not discarded on failed restoration.
