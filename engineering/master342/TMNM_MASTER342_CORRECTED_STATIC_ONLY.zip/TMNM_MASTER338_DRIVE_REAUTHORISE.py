"""Controller owns backup and rollback; never run this module directly."""
import ctypes
import ctypes.wintypes as wt
import json
import os
from pathlib import Path

SCOPES = ["https://www.googleapis.com/auth/drive.readonly",
          "https://www.googleapis.com/auth/drive.file"]


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def protect(data):
    src = (ctypes.c_byte * len(data)).from_buffer_copy(data)
    ib, ob = DATA_BLOB(len(data), src), DATA_BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(ib), None, None, None, None, 0, ctypes.byref(ob)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(ob.pbData, ob.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(ob.pbData)


def main():
    from google_auth_oauthlib.flow import InstalledAppFlow
    local = Path(os.environ["LOCALAPPDATA"]) / "TMNM" / "LocalWorker"
    token = local / "google_token.dpapi"
    backup = local / "google_token.dpapi.reauth_backup"
    new = local / "google_token.dpapi.new"
    if os.environ.get("TMNM_REAUTH_CONTROLLER") != "MASTER342":
        raise RuntimeError("CONTROLLER_REQUIRED")
    if not backup.is_file() or backup.read_bytes() != token.read_bytes():
        raise RuntimeError("VERIFIED_CONTROLLER_BACKUP_REQUIRED")
    if new.exists():
        raise RuntimeError("STALE_NEW_TOKEN_REQUIRES_REVIEW")
    try:
        flow = InstalledAppFlow.from_client_secrets_file(str(local / "client_secret.json"), SCOPES)
        creds = flow.run_local_server(port=0, open_browser=True, authorization_prompt_message="TMNM Drive reauthorisation")
        granted = getattr(creds, "granted_scopes", None)
        if granted is None:
            granted = flow.oauth2session.token.get("scope")
        if isinstance(granted, str):
            granted = granted.split()
        if not set(SCOPES).issubset(set(granted or [])):
            raise RuntimeError("REQUIRED_GRANTED_SCOPES_NOT_VERIFIED")
        info = json.loads(creds.to_json())
        info["scopes"] = sorted(set(granted))
        with new.open("xb") as f:
            f.write(protect(json.dumps(info).encode("utf-8")))
            f.flush()
            os.fsync(f.fileno())
        os.replace(new, token)
        print("REAUTHORISATION=PASS")
    finally:
        if new.exists():
            new.unlink()


if __name__ == "__main__":
    main()
